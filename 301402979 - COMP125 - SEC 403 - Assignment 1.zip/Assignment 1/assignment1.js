// Show a popup dialog box that prompts the user to specify the dimensions of a multiplication table & provides a button to generate the table
function showPopup() {
    var popup = document.getElementById("popup");
    popup.style.display = "flex"; // We set the display property to "flex" so it will be centered on the page/within the container
}

// Initialize and then dynamically generate a multiplication table (up to 10x10) based on the values specified by the user using sliders. Nested loops generate cells matching the slider values whenever the generate button is clicked
function generateTable() {
    var rows = document.getElementById("rowSlider").value;
    var columns = document.getElementById("columnSlider").value;
    var table = '<table>';
    for (var i = 1; i <= rows; i++) {
        table += '<tr>';
        for (var j = 1; j <= columns; j++) {
            table += '<td>' + (i * j) + '</td>';
        }
        table += '</tr>';
    }
    table += '</table>';

    var multiplicationTable = document.getElementById("multiplication-table");
    multiplicationTable.innerHTML = table;
}

// Event listeners that update the values displayed below the sliders based on values specified by the user
document.getElementById("rowSlider").addEventListener("input", function () {
    document.getElementById("rowCount").innerText = this.value;
});

document.getElementById("columnSlider").addEventListener("input", function () {
    document.getElementById("columnCount").innerText = this.value;
});
